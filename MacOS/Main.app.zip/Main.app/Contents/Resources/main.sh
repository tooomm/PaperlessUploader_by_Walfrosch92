#!/bin/bash

# Pfad zu Contents/Resources innerhalb der App
APP_RESOURCES="$(dirname "$0")/../Resources"

# Interpreter und Skriptpfad definieren
PYTHON_EXEC="$APP_RESOURCES/venv/bin/python3"
SCRIPT="$APP_RESOURCES/uploader.py"

# Ausführen mit Übergabe von Argumenten (z. B. bei Drag & Drop)
exec "$PYTHON_EXEC" "$SCRIPT" "$@"
