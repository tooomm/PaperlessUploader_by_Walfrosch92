#!/bin/bash

# Pfad zur Platypus-App-Ressource
APP_RESOURCES="$(dirname "$0")"

# Ausführen des mitgelieferten Python-Interpreters
"$APP_RESOURCES/venv/bin/python3" "$APP_RESOURCES/uploader.py" "$@"
